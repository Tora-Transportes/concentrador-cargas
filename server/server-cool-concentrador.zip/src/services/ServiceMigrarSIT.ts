import { ICarga } from "../models/ICargas";
import database from "../database";
import { IServiceSit } from "../domain/UseCaseCarga/entities";
import { LogsAppConcentradorRepository } from "../repositories/LogsAppConcentrador/LogsAppConcentradorRepository";

class ServiceMigrarSit implements IServiceSit {
  private logsAppConcentradorRepository: LogsAppConcentradorRepository;
  constructor() {
    this.logsAppConcentradorRepository = new LogsAppConcentradorRepository();
  }

  async carga_no_sit(idCarga: number) {
    return database("PRE_VIAGEM_ATS").where("COD_AGENDAMENTO_ATS", idCarga);
  }

  async consultarProprietarioVeiculo(placa: string) {
    return await database.raw(
      `
    select VEICULO.VEI_COD as "id_veiculo",
      TIPO_VEICULO.TV_COD as "id_tipo_veiculo",
      TIPO_VEICULO.TV_DSC as "descricao",
      VEICULO.VEI_PLACA as "placa",
      VEICULO.VEI_ANO as "ano",
      VEICULO.VEI_CHASSIS as "chassis",
      CARRETA.VEI_PLACA as "placa_carreta",
      BITREM.VEI_PLACA as "placa_bitrem",
      CADASTRO_GERAL.CG_NOME as "nome_motorista",
      CG_ID.CGI_NUM as "cpf_motorista",
      CG_ID_PROP.CGI_NUM as "documento_proprietario"
      from TIPO_VEICULO
      JOIN VEICULO ON VEICULO.TV_COD = TIPO_VEICULO.TV_COD
      LEFT JOIN VEICULO CARRETA on CARRETA.VEI_COD = VEICULO.COD_CARRETA
      LEFT JOIN VEICULO BITREM on BITREM.VEI_COD = VEICULO.COD_BITREM
      LEFT JOIN CADASTRO_GERAL on CADASTRO_GERAL.CG_COD = VEICULO.CG_MOT
      LEFT JOIN (SELECT * FROM CG_IDENTIFICACAO WHERE CG_IDENTIFICACAO.TI_COD = 2) CG_ID ON CG_ID.CG_COD = CADASTRO_GERAL.CG_COD
      LEFT JOIN (SELECT * FROM CG_IDENTIFICACAO WHERE CG_IDENTIFICACAO.TI_COD IN (6, 2, 5)) CG_ID_PROP ON CG_ID_PROP.CG_COD = CADASTRO_GERAL.CG_COD
      WHERE VEICULO.VEI_PLACA = ?
    `,
      [placa]
    );
  }

  async consultarCPFMotorista(codigoMotorista: number) {
    return database("CG_IDENTIFICACAO")
      .where("CG_COD", codigoMotorista)
      .where("TI_COD", 2)
      .first()
      .select("CGI_NUM as cpf");
  }

  async consultaIBGE(uf: string, cidade: string) {
    return database("CIDADE")
      .select([
        "CID_NOM as cidade",
        "UF_SIGLA as uf",
        "CIDADE.COD_IBGE as codigo_ibge",
      ])
      .join("ESTADO", "ESTADO.UF_COD", "CIDADE.UF_COD")
      .where("UF_SIGLA", uf)
      .where("CID_NOM", cidade)
      .first();
  }

  async converter(carga: ICarga) {
    if (!carga.placa_veiculo) {
      throw new Error("A carga não possui um veículo atribuido");
    }

    if (carga.cliente.split(" - ").length !== 3) {
      throw new Error(
        "Nome do cliente não se encontra no formato 'NOME - CNPJ - LOCAL'"
      );
    }

    const dadosVeiculo = await this.consultarProprietarioVeiculo(
      carga.placa_veiculo
    );
    if (dadosVeiculo.length === 0) {
      throw new Error("Dados do veículo não encontrados por meio da consulta");
    }

    if (!carga.origem_carga || !carga.destino_carga) {
      throw new Error("A carga não possui nenhuma origem e/ou destino.");
    }

    const [, uf_origem, cidade_origem] = carga.origem_carga.split("/");
    const [, uf_destino, cidade_destino] = carga.destino_carga.split("/");

    const ibgeOrigem = await this.consultaIBGE(uf_origem, cidade_origem);
    const ibgeDestino = await this.consultaIBGE(uf_destino, cidade_destino);

    const dataAtualizacao = new Date();

    if (
      isNaN(Number(carga.fk_filial)) ||
      carga.fk_filial === null ||
      carga.fk_filial === undefined
    ) {
      throw new Error("A carga não possui filial vinculada");
    }

    if (!carga.codigo_motorista) {
      throw new Error("A carga não possui nenhum motorista vinculado");
    }

    const dadosMotorista = await this.consultarCPFMotorista(
      carga.codigo_motorista
    );

    if (!dadosMotorista) {
      throw new Error("O motorista não possui CPF vinculado");
    }

    return {
      FIL_COD: Number(carga.fk_filial),
      STF_COD: 19,
      COD_EMPRESA_SAP: "2000",
      COD_AGENDAMENTO_ATS: carga.id,
      CGI_NUM_MOT: dadosMotorista.cpf,
      CGI_NUM_PROP: dadosVeiculo[0].documento_proprietario,
      VEI_PLACA_CAV: carga.placa_veiculo,
      VEI_PLACA_CAR: carga.placa_carreta,
      VEI_PLACA_BIT: carga.placa_bitrem,
      VEI_PLACA_TRI: null,
      PCA_DOC_FEDERAL_CLIE: carga.cliente.split(" - ")[1],
      CGI_NUM_PROGR: carga.usuario,
      SHIPMENT: carga.documento_transporte,
      CGI_NUM_RP_L: null,
      KM_TOTAL_TRANSPORTE: null,
      NOMEMAT_PROGR: null,
      COD_ORI_TKP: null,
      COD_DES_TKP: null,
      COD_ATS_CID_ORG: 0,
      VALOR_FRETE_A_PAGAR: 0,
      MDA_COD: 0,
      COD_ATS_CID_DES: 0,
      COD_SOLICITACAO_TKP: 0,
      HORA_PROGRAMACAO: dataAtualizacao,
      DATA_PROGRAMACAO: dataAtualizacao,
      DATA_HORA_PROGR: dataAtualizacao,
      DATA_HORAINSERCAOSIT: dataAtualizacao,

      COD_IBGE_ORI: ibgeOrigem?.codigo_ibge,
      COD_IBGE_DES: ibgeDestino?.codigo_ibge,
    };
  }

  async migrar(cargas: ICarga[], user: string) {
    const insercoes = [];
    for (const i of cargas) {
      insercoes.push(this.converter(i));
    }
    try {
      const insercoes = [];
      for (const i of cargas) {
        insercoes.push(this.converter(i));
      }
      await database("PRE_VIAGEM_ATS").insert(await Promise.all(insercoes));
    } catch (error) {
      const bodyLog = {
        metodo: "SERVICE-MIGRAR-ATS",
        status: "200",
        json_envio: JSON.stringify({
          requestCode: cargas[0].id ?? null,
          placa: cargas[0].placa_veiculo ?? null,
        }),
        json_retorno: JSON.stringify({
          message: "Carga já cadastrada na tabela pré viagem",
        }),
        erro: 0,
        fk_filial: String(cargas[0].fk_filial ?? 1),
      };

      await this.logsAppConcentradorRepository.create(bodyLog, user);
    }
  }

  async cancelar(cargas: ICarga[]) {
    const ids = cargas.map((i) => i.id);
    await database("PRE_VIAGEM_ATS")
      .whereIn("COD_AGENDAMENTO_ATS", ids)
      .update({
        STF_COD: 5,
      });
  }
}

export default new ServiceMigrarSit();

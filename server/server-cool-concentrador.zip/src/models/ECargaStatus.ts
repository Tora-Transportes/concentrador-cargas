enum ECargaStatus {
  AGUARDANDO_ALOCACAO = 1,
  AGUARDANDO_GR = 2,
  APROVADO_PELO_GR = 3,
  VEICULO_REPROVADO = 4,
  CARGA_CANCELADA = 5,
  DOCUMENTO_EMITIDO = 6,
}

export default ECargaStatus;
